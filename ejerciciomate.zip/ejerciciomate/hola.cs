using System;
using System.Collections.Generic;

class Program
{
    static List<TOut> Map<TIn, TOut>(List<TIn> arr, Func<TIn, int, TOut> fn)
    {
        List<TOut> newArray = new List<TOut>(arr.Count);

        for (int i = 0; i < arr.Count; i++)
        {
            newArray.Add(fn(arr[i], i));
        }

        return newArray;
    }

    static void Main()
    {
        // Ejemplo 1
        List<int> arr1 = new List<int> { 1, 2, 3 };
        Func<int, int, int> plusOne = (n, i) => n + 1;
        List<int> newArray1 = Map(arr1, plusOne);
        Console.WriteLine("Ejemplo 1:");
        Console.WriteLine(string.Join(", ", newArray1)); // [2, 3, 4]

        // Ejemplo 2
        List<int> arr2 = new List<int> { 1, 2, 3 };
        Func<int, int, int> plusI = (n, i) => n + i;
        List<int> newArray2 = Map(arr2, plusI);
        Console.WriteLine("Ejemplo 2:");
        Console.WriteLine(string.Join(", ", newArray2)); // [1, 3, 5]

        // Ejemplo 3
        List<int> arr3 = new List<int> { 10, 20, 30 };
        Func<int, int, int> constant = (n, i) => 42;
        List<int> newArray3 = Map(arr3, constant);
        Console.WriteLine("Ejemplo 3:");
        Console.WriteLine(string.Join(", ", newArray3)); // [42, 42, 42]
    }
}
//chat gpt https://chat.openai.com/share/50268d9a-715e-4007-9afe-b09dd18a47d2 //